package com.skcc.atworks.global.core.batch.domain.source.listener;

import com.skcc.atworks.global.core.batch.BatchConst;
import com.skcc.atworks.global.core.customize.enums.SourceType;
import com.skcc.atworks.domain.source.entity.embed.SourceAnalysisReport;
import com.skcc.atworks.domain.source.entity.SourceSnapshot;
import com.skcc.atworks.domain.source.repository.SourceRepository;
import com.skcc.atworks.domain.source.application.SourceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Component
@StepScope
@RequiredArgsConstructor
public class AnalysisSourceStepListener implements StepExecutionListener {

	private final SourceService sourceService;
	private final SourceRepository sourceRepository;

	@Value("#{jobParameters['sourceSnapshotId']}")
	public Long sourceSnapshotId;

	@Override
	@Transactional
	public void beforeStep(StepExecution stepExecution) {
		String stepName = stepExecution.getStepName();
		if(stepName.equals(BatchConst.ANALYSIS_SOURCE_JOB+"Step1")){
			SourceSnapshot sourceSnapshot = sourceService.findSourceSnapshotById(sourceSnapshotId);
			sourceSnapshot.getBatchInfo().started();
		}
	}

	@Override
	@Transactional
	public ExitStatus afterStep(StepExecution stepExecution) {
		String stepName = stepExecution.getStepName();
		if(stepName.equals(BatchConst.ANALYSIS_SOURCE_JOB+"Step1")){
			log.info("*** classify source finish : " + stepExecution.getSummary());
		}
		if(stepName.equals(BatchConst.ANALYSIS_SOURCE_JOB+"Step2")){
			SourceSnapshot sourceSnapshot = sourceService.findSourceSnapshotById(sourceSnapshotId);
			sourceSnapshot.complete(buildSourceAnalysisReport(sourceSnapshot));
			log.info("*** analysis source batch finish : " + stepExecution.getSummary());
		}
		return ExitStatus.COMPLETED;
	}

	private SourceAnalysisReport buildSourceAnalysisReport(SourceSnapshot sourceSnapshot) {
		SourceAnalysisReport sourceAnalysisReport = SourceAnalysisReport.builder()
				.controllerCount(getSourceTypeCount(sourceSnapshot, SourceType.CONTROLLER))
				.dataCount(getSourceTypeCount(sourceSnapshot, SourceType.DATA))
				.enumCount(getSourceTypeCount(sourceSnapshot, SourceType.ENUM))
				.build();
		return sourceAnalysisReport;
	}

	private Long getSourceTypeCount(SourceSnapshot sourceSnapshot, SourceType sourceType) {
		return sourceRepository.countBySourceSnapshotAndSourceType(sourceSnapshot, sourceType);
	}


}
