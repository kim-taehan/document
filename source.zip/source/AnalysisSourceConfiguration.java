package com.skcc.atworks.global.core.batch.domain.source;

import com.skcc.atworks.global.core.batch.BatchConst;
import com.skcc.atworks.global.core.batch.domain.source.listener.AnalysisSourceStepListener;
import com.skcc.atworks.global.core.batch.domain.source.parameter.AnalysisSourceJobParameter;
import com.skcc.atworks.global.core.batch.domain.source.processor.AnalysisSourceProcessor;
import com.skcc.atworks.global.core.batch.domain.source.processor.ClassifySourceProcessor;
import com.skcc.atworks.global.core.batch.domain.source.writer.JpaItemListWriter;
import com.skcc.atworks.global.core.customize.enums.SourceType;
import com.skcc.atworks.domain.layout.entity.Layout;
import com.skcc.atworks.domain.source.entity.SourceEntity;
import jakarta.persistence.EntityManagerFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.batch.item.database.builder.JpaItemWriterBuilder;
import org.springframework.batch.item.database.builder.JpaPagingItemReaderBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.skcc.atworks.global.core.batch.BatchConst.ANALYSIS_SOURCE_JOB;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class AnalysisSourceConfiguration {

    private final EntityManagerFactory entityManagerFactory;
    private final PlatformTransactionManager jpaTransactionManager;
    private final JobRepository jobRepository;

    private final AnalysisSourceProcessor analysisSourceProcessor;
    private final ClassifySourceProcessor classifySourceProcessor;
    private final AnalysisSourceStepListener analysisSourceStepListener;
    private final AnalysisSourceJobParameter jobParameter;

    private final int CHUCK_SIZE = 10;
    private final int POOL_SIZE = 3;

    @Bean(name = ANALYSIS_SOURCE_JOB + "jobParameter")
    @JobScope
    public AnalysisSourceJobParameter analysisSourceJobParameter(){
        return new AnalysisSourceJobParameter();
    }

    @Bean(name = ANALYSIS_SOURCE_JOB+"taskPool")
    public TaskExecutor executor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(POOL_SIZE);
        executor.setMaxPoolSize(POOL_SIZE);
        executor.setThreadNamePrefix("source-thread-");
        executor.setKeepAliveSeconds(30);
        executor.setWaitForTasksToCompleteOnShutdown(Boolean.TRUE);
        executor.initialize();
        return executor;
    }


    // JOB -> ANALYSIS_SOURCE_JOB
    @Bean(name = ANALYSIS_SOURCE_JOB)
    public Job analysisSourceJob() {
        return new JobBuilder(ANALYSIS_SOURCE_JOB, jobRepository)
                .start(step1())
                .next(step2())
                .build();
    }


    // STEP -> ANALYSIS_SOURCE_STEP1
    public Step step1() {
        return new StepBuilder(BatchConst.ANALYSIS_SOURCE_JOB+"Step1", jobRepository)
                .<Long, SourceEntity>chunk(CHUCK_SIZE, jpaTransactionManager)
                .reader(reader1())
                .processor(classifySourceProcessor)
                .writer(writer1())
                .listener(analysisSourceStepListener)
                .taskExecutor(executor())
                .build();
    }

    @Bean(name = BatchConst.ANALYSIS_SOURCE_JOB + "Step1Reader")
    @StepScope
    @Transactional(readOnly = true)
    public JpaPagingItemReader<Long> reader1() {
        Map<String, Object> params = new HashMap<>();
        params.put("sourceSnapshotId", jobParameter.getSourceSnapshotId());
        return new JpaPagingItemReaderBuilder<Long>()
                .name(BatchConst.ANALYSIS_SOURCE_JOB + "Step1Reader")
                .entityManagerFactory(entityManagerFactory)
                .pageSize(CHUCK_SIZE)
                .queryString(" SELECT se.id"
                        + "      FROM SourceEntity se"
                        + "     WHERE se.sourceSnapshot.id =:sourceSnapshotId "
                        + "  ORDER BY se.id ASC ")
                .parameterValues(params)
                .saveState(false)
                .build();
    }

    public JpaItemWriter<SourceEntity> writer1() {
        return new JpaItemWriterBuilder<SourceEntity>()
                .entityManagerFactory(entityManagerFactory)
                .build();
    }

    // STEP -> ANALYSIS_SOURCE_STEP2
    public Step step2() {
        return new StepBuilder(BatchConst.ANALYSIS_SOURCE_JOB+"Step2", jobRepository)
                .<Long, List<Layout>>chunk(CHUCK_SIZE, jpaTransactionManager)
                .reader(reader2())
                .processor(analysisSourceProcessor)
                .writer(writerList())
                .listener(analysisSourceStepListener)
                .taskExecutor(executor())
                .build();
    }

    @Bean(name = BatchConst.ANALYSIS_SOURCE_JOB + "Step2Reader")
    @StepScope
    @Transactional(readOnly = true)
    public JpaPagingItemReader<Long> reader2() {
        Map<String, Object> params = new HashMap<>();
        params.put("sourceSnapshotId", jobParameter.getSourceSnapshotId());
        params.put("sourceType", SourceType.CONTROLLER);
        JpaPagingItemReader<Long> build = new JpaPagingItemReaderBuilder<Long>()
                .name(BatchConst.ANALYSIS_SOURCE_JOB + "Step2Reader")
                .entityManagerFactory(entityManagerFactory)
                .pageSize(CHUCK_SIZE)
                .queryString(" SELECT se.id"
                        + "      FROM SourceEntity se"
                        + "     WHERE se.sourceSnapshot.id =:sourceSnapshotId "
                        + "     AND se.sourceType =:sourceType "
                        + "  ORDER BY se.id ASC ")
                .parameterValues(params)
                .saveState(false)
                .build();
        return build;
    }

    private JpaItemListWriter<Layout> writerList() {
        JpaItemWriter<Layout> writer = new JpaItemWriter<>();
        writer.setEntityManagerFactory(entityManagerFactory);
        return new JpaItemListWriter<>(writer);
    }

}
