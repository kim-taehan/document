package com.skcc.atworks.global.core.batch.domain.source.processor.work;


import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.type.Type;
import com.skcc.atworks.domain.layout.data.enums.DataType;
import com.skcc.atworks.domain.layout.data.enums.HttpMethods;
import com.skcc.atworks.domain.layout.data.enums.InOut;
import com.skcc.atworks.domain.layout.entity.Col;
import com.skcc.atworks.domain.layout.entity.embed.ColAttribute;
import com.skcc.atworks.domain.source.entity.SourceEntity;
import com.skcc.atworks.global.core.batch.domain.source.processor.data.Columns;
import com.skcc.atworks.global.core.batch.domain.source.processor.data.SourceInfo;
import com.skcc.atworks.global.core.customize.enums.SourceType;
import com.skcc.atworks.global.core.customize.framework.FrameWorkResolve;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.ObjectUtils;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static com.skcc.atworks.global.core.customize.constants.SourceConst.*;

@Slf4j
public class DtoClassAnalysis {

    private final FrameWorkResolve frameWorkResolve;
    private final DtoFinder dtoFinder;

    private InOut inOut;
    private HttpMethods httpMethods;

    @Builder
    public DtoClassAnalysis(DtoFinder dtoFinder, FrameWorkResolve frameWorkResolve) {
        this.dtoFinder = dtoFinder;
        this.frameWorkResolve = frameWorkResolve;
    }

    // request
    public Columns joinRequest(SourceInfo sourceInfo, MethodDeclaration method, String fullUrl) {
        
        // 초기 데이터
        initData(InOut.IN, method);
        Columns columns = new Columns();

        for (Parameter parameter : method.getParameters()) {
            try {
                // param annotations
                addRootCol(sourceInfo, columns, parameter);
            } catch (RuntimeException e) {
                log.error("joinRequest error -> ", e);
            }
        }
        return checkedVariablePath(columns, fullUrl);
    }

    // response
    public Columns joinResponse(SourceInfo sourceInfo, MethodDeclaration method) {
        // 초기 데이터
        initData(InOut.OUT, method);
        Columns columns = new Columns();

        try {
            // typeName 으로 등록된 DTO 클래스 찾음
            dtoFinder.findDtoSource(sourceInfo, method.getTypeAsString()).ifPresent(dtoSource -> {
                columns.addVoClass(dtoSource);
                dataSourceToCols(sourceInfo, dtoSource).forEach(columns::addColumn);
            });
        } catch (RuntimeException e) {
            log.error("joinResponse error -> ", e);
        }

        return columns;
    }

    private void initData(InOut out, MethodDeclaration method) {
        this.inOut = out;
        httpMethods = frameWorkResolve.getHttpMethod(method);
    }

    private boolean checkedRootList(Parameter parameter) {
        List<Node> nodes = parameter.getType().getChildNodes();
        return nodes.size() == 2 && nodes.get(0).toString().toLowerCase().indexOf("list") != -1;
    }

    private void addRootCol(SourceInfo sourceInfo, Columns columns, Parameter parameter ) {

        List<String> annotations = frameWorkResolve.getAnnotationNames(parameter.getAnnotations());
        String typeName = parameter.getTypeAsString();
        String argName = parameter.getNameAsString();

        // string, number, boolean, list<?>, arraylist<?>, linkedlist<?>
        if (isBasicType(typeName)) {
            columns.addColumn(annotations, createCol(argName, argName, getDataType(typeName)), httpMethods);
        }

        else if (checkedRootList(parameter)) {
            addRootListCol(sourceInfo, columns, parameter);
        }
        else {
            dtoFinder.findDtoSource(sourceInfo, typeName).ifPresent(dtoSource -> {
                // enum data 처리
                if(dtoSource.getSourceType() == SourceType.ENUM){
                    columns.addColumn(annotations, createEnumsCol(argName, typeName), httpMethods);
                }
                else{
                    addRootDtoCol(sourceInfo, columns, annotations, dtoSource);
                }
            });
        }
    }

    private void addRootDtoCol(SourceInfo sourceInfo, Columns columns, List<String> annotations, SourceEntity dtoSource) {
        columns.addVoClass(dtoSource);
        List<Col> cols = dataSourceToCols(sourceInfo, dtoSource);
        for (Col col : cols) {
            columns.addColumn(annotations, col, httpMethods);
        }
    }

    private void addRootListCol(SourceInfo sourceInfo, Columns columns, Parameter parameter) {
        Col rootList = createCol("", "", DataType.ROOT_LIST);
        String dtoType = parameter.getType().getChildNodes().get(1).toString();
        dtoFinder.findDtoSource(sourceInfo, dtoType).ifPresent(dtoSource -> {
            columns.addVoClass(dtoSource);
            List<Col> cols = dataSourceToCols(sourceInfo, dtoSource);
            cols.forEach(rootList::addCol);
            columns.addColumn(rootList);
        });
    }

    private List<Col> dataSourceToCols(SourceInfo sourceInfo, SourceEntity dtoSource) {
        List<Col> cols = new LinkedList<>();
        CompilationUnit unit = frameWorkResolve.convertFileToUnit(dtoSource.originFile()).orElse(null);
        if (!ObjectUtils.isEmpty(unit) && isNotRecursiveData(sourceInfo, dtoSource)) {

            SourceInfo dtoSourceInfo = new SourceInfo(
                    dtoSource,
                    "",
                    frameWorkResolve.getImportClasses(unit),
                    null
            );

            String className = dtoSource.getClassInfo().getClassName();
            unit.findAll(ClassOrInterfaceDeclaration.class).stream()
                    .filter(type -> type.getNameAsString().equals(className))
                    .findFirst().ifPresent(classObject -> {
                        combineDataClassObject(classObject, dtoSourceInfo, cols);
                    });
        }
        return cols;
    }


    /**
     * Data 클래스의 내부 멤버들의 List<Col> 에 추가합니다.
     */
    private void combineDataClassObject(
            ClassOrInterfaceDeclaration type,
            SourceInfo sourceInfo,
            List<Col> list
    ){
        // Data class
        for(FieldDeclaration filed : type.getFields()){
            List<VariableDeclarator> vars = filed.getVariables();
            for(VariableDeclarator var : vars) {
                addCol(filed, var, list, sourceInfo);
            }
        }
    }

    private void addCol(
            FieldDeclaration filed,
            VariableDeclarator var,
            List<Col> cols,
            SourceInfo sourceInfo
    ){

        final String typeName = var.getNameAsString();
        final String variableDesc = frameWorkResolve.getColumnDesc(filed, typeName);

        Type type = var.getType();
        if (isBasicType(type.asString())) {
            cols.add(createCol(typeName, variableDesc, getDataType(type.asString())));
        }
        else{
            dtoFinder.findDtoSource(sourceInfo, getVariableType(type)).ifPresent( dtoSource -> {
                // enum data 처리
                if(dtoSource.getSourceType() == SourceType.ENUM){
                    cols.add(createEnumsCol(typeName, variableDesc));
                }
                else{
                    Col subCol = createCol(typeName, variableDesc, getDataTypeListOrObject(type));
                    dataSourceToCols(sourceInfo, dtoSource).forEach(subCol::addCol);
                    cols.add(subCol);
                }
            });
        }
    }


    private String getVariableType(Type type) {
        List<Node> nodes = type.getChildNodes();
        return nodes.size() == 1 ? type.toString() : nodes.get( 1 ).toString();
    }

    private DataType getDataTypeListOrObject(Type type) {
        return LIST_SHAPES.contains( type.getChildNodes().get( 0 ).toString() ) ? DataType.LIST : DataType.OBJECT;
    }

    private boolean isNotRecursiveData(SourceInfo sourceInfo, SourceEntity dtoSource) {
        return !sourceInfo.getFileName().equals(dtoSource.getFileInfo().getFileName());
    }

    private Col createEnumsCol(String physicalName, String logicalName) {
        return createCol( physicalName, "Enum(" + logicalName + ")", DataType.STRING );
    }

    private Col createCol(String physicalName, String logicalName, DataType dataType){
        ColAttribute colAttribute = ColAttribute.builder()
                .physicalName( physicalName )
                .logicalName( logicalName )
                .dataType( dataType )
                .build();

        return Col.builder()
                .inOut(inOut)
                .colAttribute(colAttribute)
                .build();
    }


    // aia 사이트에서 argument에는 없는데 PathVariable 사용하는 거지같은 경우 존재
    private Columns checkedVariablePath(Columns columns, String fullUrl) {

        columns.findRootColByPhysicalName(PATH_VARIABLE).ifPresent( pathVariableCol -> {
            Arrays.stream(fullUrl.split("/"))
                    .filter(this::checkPathVariable)
                    .map(this::getPathVariableName)
                    .forEach(path -> {
                        pathVariableCol.findColByPhysicalName(path).ifPresentOrElse(
                                col -> log.debug("이미 등록됨"),
                                () -> pathVariableCol.addCol(createCol(path, path, DataType.STRING))
                        );
                    });
        });
        return columns;
    }

    private String getPathVariableName(String path) {
        return path.substring(1, path.length() - 1);
    }

    private boolean checkPathVariable(String path) {
        return path.startsWith("{") && path.endsWith("}");
    }
}
