package com.skcc.atworks.global.core.batch.domain.source.processor.work;

import com.skcc.atworks.global.core.batch.domain.source.processor.data.SourceInfo;
import com.skcc.atworks.domain.source.entity.SourceEntity;
import com.skcc.atworks.domain.source.application.SourceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class DtoFinder {

    private final SourceService sourceService;

    @Deprecated
    public Optional<SourceEntity> findDtoSource(SourceInfo sourceInfo, String typeName){
        //Table data 조회
        List<SourceEntity> dtoSources = sourceService.findDto(sourceInfo.getSourceSnapshot(), typeName);
        return mappingDtoClass(sourceInfo.source(), sourceInfo.importClassNames(), dtoSources);
    }

    private static Optional<SourceEntity> mappingDtoClass(SourceEntity sourceEntity, List<String> importClassNames, List<SourceEntity> dtoSources) {

        //import, package 등을 체크하여 mapping 되는 class 객체를 조회

        // 1. vo 패키지명 + 클래스명 = import class 존재하는 경우
        for (SourceEntity dtoSource : dtoSources) {
            if(importClassNames.contains(dtoSource.classFullName())){
                return Optional.of(dtoSource);
            }
        }
        // 2. vo 패키지와 controller 의 패키지가 동일한 경우
        for (SourceEntity dtoSource : dtoSources) {
            if(sourceEntity.getClassInfo().getPackageName().equals(dtoSource.getClassInfo().getPackageName())){
                return Optional.of(dtoSource);
            }
        }
        // 3. vo 패키지명  = import .* 동일한 경우 처리
        for (SourceEntity dtoSource : dtoSources) {
            if(importClassNames.indexOf(dtoSource.getClassInfo().getPackageName()) != -1){
                return Optional.of(dtoSource);
            }
        }
        return Optional.empty();
    }

}
