package com.skcc.atworks.global.core.batch.domain.source.processor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.skcc.atworks.global.core.batch.domain.source.processor.data.Columns;
import com.skcc.atworks.global.core.batch.domain.source.processor.data.MethodInfo;
import com.skcc.atworks.global.core.batch.domain.source.processor.work.DtoClassAnalysis;
import com.skcc.atworks.global.core.batch.domain.source.processor.work.DtoFinder;
import com.skcc.atworks.global.core.batch.domain.source.processor.data.SourceInfo;
import com.skcc.atworks.global.error.exception.BusinessException;
import com.skcc.atworks.global.core.customize.framework.FrameWorkResolve;
import com.skcc.atworks.domain.layout.data.LayoutTrackVo;
import com.skcc.atworks.domain.layout.entity.embed.ServiceInfo;
import com.skcc.atworks.domain.layout.entity.Layout;
import com.skcc.atworks.domain.layout.data.enums.HttpMethods;
import com.skcc.atworks.domain.layout.data.enums.InflowPath;
import com.skcc.atworks.domain.source.entity.SourceEntity;
import com.skcc.atworks.domain.layout.application.LayoutPerformService;
import com.skcc.atworks.domain.source.application.SourceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.skcc.atworks.global.util.HttpUtils.mergeUrls;


@Slf4j
@Component("AnalysisSourceProcessor")
@StepScope
@Transactional
@RequiredArgsConstructor
public class AnalysisSourceProcessor implements ItemProcessor<Long, List<Layout>> {

	private final SourceService sourceService;
	private final DtoFinder dtoFinder;
	private final FrameWorkResolve frameWorkResolve;
	private final LayoutPerformService layoutPerformService;


	@Override
	public List<Layout> process(@NotNull Long sourceEntityId) throws Exception {
		SourceEntity source = sourceService.findSourceById(sourceEntityId);
		SourceInfo sourceInfo = analysisSource(source);
		return sourceInfo != null ? sourceInfo.layouts() : null;
	}

	private SourceInfo analysisSource(SourceEntity source) {
		try{
			CompilationUnit unit = frameWorkResolve.convertFileToUnit(source.originFile())
					.orElseThrow(() -> new BusinessException("file analysis error"));
			return analysisClass(unit, source);
		} catch (Exception e){
			log.error("오류발생" + e.getMessage());
			source.setMessage(e.getClass().toString());
		}
		return null;
	}

	private SourceInfo analysisClass(CompilationUnit unit, SourceEntity source){

		ClassOrInterfaceDeclaration type = (ClassOrInterfaceDeclaration) unit.getType(0);

		SourceInfo sourceInfo = new SourceInfo(
				source
				, frameWorkResolve.getUrlOfClass(type) 		// controller url mapping info
				, frameWorkResolve.getImportClasses(unit)   // import class names
				, new ArrayList<>()
		);
		// for methods
		for (MethodDeclaration method : type.findAll(MethodDeclaration.class)) {

			analysisMethod(sourceInfo, method);
		}

		return sourceInfo;
	}

	private void analysisMethod(SourceInfo sourceInfo, MethodDeclaration method) {

		HttpMethods httpMethods = frameWorkResolve.getHttpMethod(method);
		if (httpMethods.equals(HttpMethods.NONE)) {
			return;
		}

		DtoClassAnalysis dtoClassAnalysis = DtoClassAnalysis.builder()
				.dtoFinder(dtoFinder)
				.frameWorkResolve(frameWorkResolve)
				.build();

		// method url mapping info
		String[] urlPattens = frameWorkResolve.getUrlOfMethod(method);

		// Multiple mapping information can come. @GetMapping({"/api/v1","/api/v2"})
		for(String urlPattern : urlPattens){
			String fullUrl = mergeUrls(sourceInfo.classUrl(), urlPattern);

			Columns requestBody = dtoClassAnalysis.joinRequest(sourceInfo, method, fullUrl);
			Columns responseBody = dtoClassAnalysis.joinResponse(sourceInfo, method);

			MethodInfo methodInfo = MethodInfo.builder()
					.method(method)
					.url(fullUrl)
					.httpMethods(httpMethods)
					.requestBody(requestBody)
					.responseBody(responseBody)
					.build();
			try {
				saveLayout(sourceInfo, methodInfo);

				log.info("[Method call]: {}, {}",fullUrl, httpMethods);


			} catch (Exception e) {
				log.info("[Method error]: {}, {}",fullUrl, method);
//				log.error("{}.{} 오류발생 {}", sourceInfo.getFileName() , methodInfo.method().getNameAsString(), e.getMessage());
			}

		}
	}

	private void saveLayout(SourceInfo sourceInfo, MethodInfo methodInfo) {

		ServiceInfo serviceInfo = frameWorkResolve.getServiceInfo(sourceInfo, methodInfo);
		findExistingApi(methodInfo, serviceInfo.getServiceId()).ifPresentOrElse(
			updateLayout -> {
				sourceInfo.addLayout(updateLayout);
			},
			() -> {
				Layout saveLayout = initLayout(sourceInfo, methodInfo);
				sourceInfo.addLayout(saveLayout);
			}
		);
	}

	private Layout initLayout(SourceInfo sourceInfo, MethodInfo methodInfo) {
		ServiceInfo serviceInfo = frameWorkResolve.getServiceInfo(sourceInfo, methodInfo);
		Layout layout = layoutPerformService.initLayout(InflowPath.SOURCE, serviceInfo, methodInfo.url(), methodInfo.httpMethods());
		methodInfo.requestBody().getColumns().forEach(layout::addCol);
		methodInfo.responseBody().getColumns().forEach(layout::addCol);
		return layout;
	}

	private Optional<Layout> findExistingApi(MethodInfo methodInfo, String serviceId) {
		LayoutTrackVo layoutTrackVo = LayoutTrackVo.builder()
				.unknownUrl(methodInfo.url())
				.httpMethods(methodInfo.httpMethods())
				.serviceId(serviceId)
				.build();

		return layoutPerformService.trackLayout(layoutTrackVo);
	}
}