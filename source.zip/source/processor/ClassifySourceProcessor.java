package com.skcc.atworks.global.core.batch.domain.source.processor;

import com.github.javaparser.ast.CompilationUnit;
import com.skcc.atworks.global.error.exception.BusinessException;
import com.skcc.atworks.global.core.customize.enums.SourceType;
import com.skcc.atworks.global.core.customize.framework.FrameWorkResolve;
import com.skcc.atworks.domain.source.entity.embed.ClassInfo;
import com.skcc.atworks.domain.source.entity.SourceEntity;
import com.skcc.atworks.domain.source.application.SourceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

/**
 * 소스 분석 배치
 * @since 2021-10-01 최초생성
 * @apiNote 2022-02-25 모듈화 작업 진행
 */
@Slf4j
@Component("ClassifySourceProcessor")
@StepScope
@RequiredArgsConstructor
public class ClassifySourceProcessor implements ItemProcessor<Long, SourceEntity> {

	private final SourceService sourceService;
	private final FrameWorkResolve frameWorkResolve;

	@Override
	public SourceEntity process(@NotNull Long sourceEntityId) throws Exception {

		SourceEntity source = sourceService.findSourceById(sourceEntityId);
		try {
			log.info("소스분석 -> {}", source.getFileInfo().getFileName());
			updateSource(source);
		} catch (Exception e) {
			log.error("소스 분석 실패 " + e.getMessage());
		}
		return source;

	}

	private void updateSource(SourceEntity source) {
		try {
			CompilationUnit unit = frameWorkResolve.convertFileToUnit(source.originFile())
					.orElseThrow(() -> new BusinessException("file analysis error"));

			// source type 구하기
			SourceType sourceType = frameWorkResolve.getSourceType(unit);
			source.setSourceType(sourceType);
			if (sourceType != SourceType.NONE) {
				source.setClassInfo(buildClassInfo(unit));
			}
		}  catch (Exception e) {
			source.setSourceType(SourceType.NONE);
			source.setMessage(e.getClass().toString());
		}
	}

	private ClassInfo buildClassInfo(CompilationUnit unit) {
		return ClassInfo.builder()
				.packageName(frameWorkResolve.getPackage(unit))
				.className(unit.getType(0).getNameAsString())
				.build();
	}
}