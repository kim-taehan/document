package com.skcc.atworks.global.core.batch.domain.source.processor.data;

import com.skcc.atworks.domain.layout.entity.embed.ColAttribute;
import com.skcc.atworks.domain.layout.entity.Col;
import com.skcc.atworks.domain.layout.data.enums.DataType;
import com.skcc.atworks.domain.layout.data.enums.HttpMethods;
import com.skcc.atworks.domain.layout.data.enums.InOut;
import com.skcc.atworks.domain.source.entity.SourceEntity;

import java.util.*;

import static com.skcc.atworks.global.core.customize.constants.SourceConst.PATH_VARIABLE;
import static com.skcc.atworks.global.core.customize.constants.SourceConst.QUERY_STRING;

public record Columns(List<Col> columns, List<SourceEntity> voClasses) {

    public Columns() {
        this(initListCol(), new Vector<>());
    }

    private static List<Col> initListCol() {
        List<Col> list = new LinkedList<>();
        list.add(getPathVariableCol());
        list.add(getQueryStringCol());
        return list;
    }

    private static Col getPathVariableCol() {
        return Col.builder()
                .inOut( InOut.IN)
                .colAttribute(collAttributeBuild(PATH_VARIABLE, DataType.PATH_VARIABLE))
                .build();
    }

    private static Col getQueryStringCol() {
        return Col.builder()
                .inOut(InOut.IN)
                .colAttribute(collAttributeBuild(QUERY_STRING, DataType.QUERY_STRING))
                .build();
    }

    private static ColAttribute collAttributeBuild(String name, DataType dataType) {
        return ColAttribute.builder()
                .logicalName(name)
                .physicalName(name)
                .dataType(dataType)
                .build();
    }

    public List<Col> getColumns() {
        int PATH_VARIABLE_INDEX = 0;
        int QUERY_STRING_INDEX = 1;

        if(columns.get(QUERY_STRING_INDEX).getChildren().size() == 0){
            columns.remove(QUERY_STRING_INDEX);
        }
        if(columns.get(PATH_VARIABLE_INDEX).getChildren().size() == 0){
            columns.remove(PATH_VARIABLE_INDEX);
        }
        return columns;
    }

    public void addVoClass(SourceEntity voClass) {
        voClasses.add(voClass);
    }

    public void addColumn(List<String> annotationNames, Col col, HttpMethods httpMethod) {
        int PATH_VARIABLE_INDEX = 0;
        int QUERY_STRING_INDEX = 1;
        if(annotationNames.contains("PathVariable")){
            columns.get(PATH_VARIABLE_INDEX).addCol(col);
        } else if (httpMethod.equals(HttpMethods.GET)) {
            columns.get(QUERY_STRING_INDEX).addCol(col);
        } else {
            columns.add(col);
        }
    }

    public void addColumn(Col col) {
        columns.add(col);
    }


    public Optional<Col> findRootColByPhysicalName(String physicalName) {
        return columns().stream()
                .filter(col -> col.getColAttribute().getPhysicalName().equals(physicalName))
                .findFirst();
    }
}
