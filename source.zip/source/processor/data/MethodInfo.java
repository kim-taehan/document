package com.skcc.atworks.global.core.batch.domain.source.processor.data;

import com.github.javaparser.ast.body.MethodDeclaration;
import com.skcc.atworks.domain.layout.data.enums.HttpMethods;
import lombok.Builder;

public record MethodInfo(
        MethodDeclaration method,
        HttpMethods httpMethods,
        String url,
        Columns requestBody,
        Columns responseBody

){
    @Builder
    public MethodInfo(MethodDeclaration method, HttpMethods httpMethods, String url, Columns requestBody, Columns responseBody) {
        this.method = method;
        this.httpMethods = httpMethods;
        this.url = url;
        this.requestBody = requestBody;
        this.responseBody = responseBody;
    }



}
