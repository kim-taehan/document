package com.skcc.atworks.global.core.batch.domain.source.processor.data;

import com.skcc.atworks.domain.layout.entity.Layout;
import com.skcc.atworks.domain.source.entity.SourceEntity;
import com.skcc.atworks.domain.source.entity.SourceSnapshot;

import java.util.List;
import java.util.Optional;

public record  SourceInfo(SourceEntity source, String classUrl, List<String> importClassNames, List<Layout> layouts){
    public String getFileName() {
        return source.getFileInfo().getFileName();
    }
    public SourceSnapshot getSourceSnapshot() {
        return source.getSourceSnapshot();
    }
    public void addLayout(Layout layout) {
        layouts.add(layout);
    }

    public Optional<String> getPackageName() {
        try {
            return Optional.of(source.getClassInfo().getPackageName());
        } catch (NullPointerException ne) {
            return Optional.empty();
        }
    }
}

