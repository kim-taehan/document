package com.skcc.atworks.global.core.batch.domain.source.parameter;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import java.util.Date;

@Slf4j
@Getter
@NoArgsConstructor
public class AnalysisSourceJobParameter {

    @Value("#{jobParameters[sourceSnapshotId]}")
    private Long sourceSnapshotId;

    @Value("#{jobParameters[createDate]}")
    private Date createDate;

}
